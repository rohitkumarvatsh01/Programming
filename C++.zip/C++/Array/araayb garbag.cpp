#include<iostream>
using namespace std;

int main()
{
    int arr[]={1,2,3,4,5};
    cout<<arr[5];
    //garbage value le leta agr jo array me define na hua to

    return 0;
}