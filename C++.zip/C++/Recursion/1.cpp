// #include<iostream>
// using namespace std;

// int factorial(int n){
//     if(n==0){
//         return 1;
//     }
//     return n*factorial(n-1);
// }
// int main(){
//     int n;
//     cin>>n;
//     cout<<factorial(n)<<endl;

// return 0;
// }

// #include<iostream>
// using namespace std;

// int pow(int n){
//     if(n==0){
//         return 1;
//     }
//     return 2*pow(n-1);
// }
// int main(){
//     int n;
//     cin>>n;
//     cout<<pow(n)<<endl;


// return 0;
// }

// #include<iostream>
// using namespace std;

// void count(int n){
//     if(n==0){
//         return;
//     }
//     cout<<n<<endl;

//     count(n-1);
// }
// int main(){
//     int n;
//     cin>>n;
//     count(n);

// return 0;
// }

#include<iostream>
using namespace std;

void print(int n){
    if(n==0){
        return;
    }
    print(n-1);

    co
}
int main(){
    int n;
    cin>>n;


return 0;
}