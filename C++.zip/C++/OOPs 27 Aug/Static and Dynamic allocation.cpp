#include<iostream>
using namespace std;

class Hero{
    private:
    int health;

    public:
    char level;

    void print(){
        cout<<level<<endl;
    }

    int getHealth(){
        return Health;
    }

    char getHealth(){
        return level;
    }

    void setHealth(int h){
        Health=h;
    }

    void setLevel(char ch){
        level=ch;
    }
};

int main(){
    

return 0;
}