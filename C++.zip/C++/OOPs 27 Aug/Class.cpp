#include<iostream>
using namespace std;

class Hero{
    //Property
    //int value;
};

int main(){ 

    //Creation of Object
    Hero h1;
    cout<<"Size of h1: "<<sizeof(h1)<<endl;
        
return 0;
}