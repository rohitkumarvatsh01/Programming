#include<iostream>
#include"Hero.cpp"

using namespace std;

int main(){
    Hero h1;

    cout<<"Size of :"<<sizeof(h1)<<endl;
}