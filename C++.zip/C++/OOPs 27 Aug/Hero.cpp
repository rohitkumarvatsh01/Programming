class Hero{
    //Property
    int value;
};