#include<iostream>
using namespace std;
int main()
{

    int a = 4;
    cout<<"Size of int :- "<<sizeof(a)<<endl;


    float b = 2.2;
    cout<<"Size of float :- "<<sizeof(b)<<endl;


    char c = 'A';
    cout<<"Size of char :- "<<sizeof(c)<<endl;


    bool d = false;
    cout<<"Size of bool:- "<<sizeof(d)<<endl;


    double e = 1.23;
    cout<<"Size of double :- "<<sizeof(e)<<endl;


    short int f;
    cout<<"Size of short int :- "<<sizeof(f)<<endl;


    long int g;
    cout<<"Size of long int :- "<<sizeof(g)<<endl;


    return 0;
}