#include<iostream>
using namespace std;
int main()
{
    int n;
    cout<<"Enter the num which are you check odd or even:- "<<endl;
    cin>>n;

    if(n%2==0){
        cout<<"The number is Even "<<endl;
    }
    else
    {
        cout<<"The number is Odd "<<endl;

    }


    return 0;
}