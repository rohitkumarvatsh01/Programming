#include<iostream>
using namespace std;
int main()
{
    
  int a;
  cout<<"Enter the value of a:- "<<endl;
  cin>>a;

  int b;
  cout<<"Enter the value of b:- "<<endl;
  cin>>b;

  int c;
  cout<<"Enter the value of c:- "<<endl;
  cin>>c;

  int average = a + b + c / 3;

  cout<<"The average of three number is :- "<<average<<endl;
    return 0;
}