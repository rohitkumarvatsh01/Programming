#include<iostream>
using namespace std;
int main()
{
    cout<<"Namaste Duniya";

    return 0;
}