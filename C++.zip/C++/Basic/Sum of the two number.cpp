#include<iostream>
using namespace std;
int main()
{
    int a;
    cout<<"Enter the value of a:- "<<endl;
    cin>>a;

    int b;
    cout<<"Enter the value of b:- "<<endl;
    cin>>b;


    int sum = a + b;
    cout<<"The sum of two number:- "<<sum<<endl;
    


    return 0;
}