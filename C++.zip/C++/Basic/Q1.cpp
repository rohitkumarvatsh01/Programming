#include<iostream>
using namespace std;
int main()
{
    int a=9;
    if(a==9){
        cout<<"NINTY";
    }
    if(a>0){
        cout<<"POSTIVE";
    }
    else
    {
        cout<<"NIGATIVE";
    }


    return 0;
}