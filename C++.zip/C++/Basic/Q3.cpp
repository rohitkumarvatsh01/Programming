#include<iostream>
using namespace std;
int main()
{
    int a=24;
    if(a>20){
        cout<<"Love";
    }
    else if(a==24){
        cout<<"C++";
    }
    else{
        cout<<"Ye print na hoga"<<endl;
    }


    return 0;
}