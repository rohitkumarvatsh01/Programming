#include<iostream>
using namespace std;
int main()
{
    
    int a;
    cout<<"Enter the value of a:- "<<endl;
    cin>>a;
    int b;
    cout<<"Enter the value of b:- "<<endl;
    cin>>b;

    if(a<b){
        cout<<"The b number is the grater"<<endl;
        }
    else{
        cout<<"The a number is the greater"<<endl;
    }

    return 0;
}