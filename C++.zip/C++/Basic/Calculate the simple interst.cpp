#include<iostream>
using namespace std;
int main()
{
    int p;
    cout<<"Enter the value of p:- "<<endl;
    cin>>p;

    int r;
    cout<<"Enter the value of r:- "<<endl;
    cin>>r;

    int t;
    cout<<"Enter the value of t:- "<<endl;
    cin>>t;

    int simpleIntrest = p*r*t/100;

    cout<<"The simple intrest is:- "<<simpleIntrest<<endl;


    return 0;
}