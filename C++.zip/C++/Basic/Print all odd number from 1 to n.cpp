#include<iostream>
using namespace std;
int main()
{
    int n;
    int a=1;
    while(a<1){
        cout<<a;
        a=a+2;
    }


    return 0;
}