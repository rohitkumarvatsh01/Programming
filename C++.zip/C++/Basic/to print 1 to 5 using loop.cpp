#include<iostream>
using namespace std;
int main()
{
    int n;
    cout<<"Enter the Number:- "<<endl;
    cin>>n;

    for(int i=1; i<=n; i++){
        cout<<n;
    }
    n=n+1;


    return 0;
}