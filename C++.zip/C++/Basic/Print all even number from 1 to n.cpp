#include<iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int num=2;
    while(num>n){
    cout<<num;
    }
    num=num+2;


    return 0;
}