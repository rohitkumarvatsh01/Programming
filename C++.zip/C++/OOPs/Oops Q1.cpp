#include<iostream>
using namespace std;

class Q1
{
private:
    int hello=2;;
};


int main(){
    Q1 obj;
    cout<<"Size of :- "<<sizeof(obj)<<endl;
    return 0;

}