#include<iostream>
using namespacestd;
int main(){
    cout<<"Hello World!";
    return 0;
}