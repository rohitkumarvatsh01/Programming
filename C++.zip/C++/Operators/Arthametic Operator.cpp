#include<iostream>
using namespace std;
int main()
{
    int a;
    int b;

    cout<<"Enter the value of a:- "<<endl;
    cin>>a;    
    cout<<"Enter the value of b:- "<<endl;
    cin>>b;

    int sum = a + b;
    cout<<"The sum of the a + b is :- "<<sum<<endl;

    int sub = a - b;
    cout<<"The sum of the a - b is :- "<<sub<<endl;

    int mul = a * b;
    cout<<"The sum of the a + b is :- "<<mul<<endl;

    int div = a / b;
    cout<<"The sum of the a / b is :- "<<div<<endl;

    
    return 0;
}