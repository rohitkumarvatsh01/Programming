#include<iostream>
using namespace std;

int main()
{
    //Left Shift
    cout<<(17>>1)<<endl;
    cout<<(17>>2)<<endl;
    
    //Right Shift
    cout<<(17<<1)<<endl;
    cout<<(17<<2)<<endl;

    return 0;
}