#include<iostream>
using namespace std;

int main()
{
    // int marks[]={21, 22, 23, 24, 25};
    
    // cout<<marks[0]<<endl;
    // cout<<marks[1]<<endl;
    // cout<<marks[2]<<endl;
    // cout<<marks[3]<<endl;
    // cout<<marks[4]<<endl;

    int marks[5];

    cin>>marks[0];
    cin>>marks[1];
    cin>>marks[2];
    cin>>marks[3];
    cin>>marks[4];

    cout<<marks[0]<<" ";
    cout<<marks[1]<<" ";
    cout<<marks[2]<<" ";
    cout<<marks[3]<<" ";
    cout<<marks[4]<<" ";


    return 0;
}