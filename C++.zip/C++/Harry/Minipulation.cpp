#include<iostream>
using namespace std;

int main()
{
    int a=3;
    int b=33;
    int c=333;
    int d=3333;
    int e=33333;
    int f=333333;
    int g=3333333;
    int h=33333333;
    int i=333333333;
    int j=3333333333;

    cout<<"The value of a :- "<<setw(11)<<a<<endl;
    cout<<"The value of b :- "<<setw(11)<<b<<endl;
    cout<<"The value of c :- "<<setw(11)<<c<<endl;
    cout<<"The value of d :- "<<setw(11)<<d<<endl;
    cout<<"The value of e :- "<<setw(11)<<e<<endl;
    cout<<"The value of f :- "<<setw(11)<<f<<endl;
    cout<<"The value of g :- "<<setw(11)<<g<<endl;
    cout<<"The value of h :- "<<setw(11)<<h<<endl;
    cout<<"The value of a :- "<<setw(11)<<i<<endl;
    cout<<"The value of a :- "<<setw(11)<<j<<endl;


    return 0;
}