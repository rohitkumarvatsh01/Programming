#include<iostream>
using namespace std;
int main(){
    /*int arr[4]={1,2,3,4};
    cout<<arr[2]<<endl;*/

    int arr[4];
    int arr[0]={1};
    int arr[1]={2};
    int arr[2]={3};
    int arr[3]={4};
    cout<<arr[1];

    return 0;
}