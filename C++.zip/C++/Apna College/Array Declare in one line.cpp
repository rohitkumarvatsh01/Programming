#include<iostream>
using namespace std;

int main(){
    int array[10]={10,20,30,40,50,60,70,80,90,100};
    cout<<array[0]<<endl;
    cout<<array[1]<<endl;
    cout<<array[2]<<endl;
    cout<<array[3]<<endl;
    cout<<array[4]<<endl;
    cout<<array[5]<<endl;
    cout<<array[6]<<endl;
    cout<<array[7]<<endl;
    cout<<array[8]<<endl;
    cout<<array[9]<<endl;


    return 0;

}