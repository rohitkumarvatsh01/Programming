#include <iostream>
using namespace std;

int main()
{
    int array[5];
    array[0] = 10;
    array[1] = 20;
    array[2] = 30;
    array[3] = 40;
    array[4] = 50;

    cout << array[4] << endl;

    return 0;
}