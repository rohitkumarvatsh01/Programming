#include<iostream>
using namespace std;

int main(){
    int age;
    cout<<"Enter your age:- ";
    cin>>age;

    if(age<80){
        cout<<"You can Drive";
    }
    else if (age>18)
    {
        cout<<"You can not Drive";
    }
    else{
        cout<<"You can not Drive";
    }
    return 0;
}
