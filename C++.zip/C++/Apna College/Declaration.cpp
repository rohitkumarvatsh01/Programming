#include <iostream>
using namespace std;
int main()
{
    int a;
    cout << "size of int " << sizeof(a) << endl;

    float b;
    cout << "size of float " << sizeof(b) << endl;

    char c;
    cout << "size of char " << sizeof(c) << endl;

    bool d;
    cout << "size of bool " << sizeof(d) << endl;

    short int si;
    cout << "size of short " << sizeof(si) << endl;

    long int li;
    cout << "size of long " << sizeof(li) << endl;

    return 0;
}