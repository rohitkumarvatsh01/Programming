#include<iostream>
using namespace std;
int main(){
    int a;
    cout<<"Enter the value of a:- "<<endl;
    cin>>a;
    int b;
    cout<<"Enter the value of b:- "<<endl;
    cin>>b;
    int c=a+b;
    cout<<"The sum of a+b is:- "<<endl;
    cout<<c<<endl;

    return 0;
}