#include<iostream>
using namespace std;
int main(){
    int num1;
    int num2;
    int op;

    cout<<"Enter the value of num1:- "<<endl;
    cin>>num1;
    cout<<"Enter the value of num2:- "<<endl;
    cin>>num2;

    switch (char)
    {
    case(op='+'){
        cout<<"The value of a+b:- "<<a+b<<endl;
        break;
    }
    
    default:
        break;
    }
}