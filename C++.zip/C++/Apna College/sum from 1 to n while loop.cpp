#include<iostream>
using namespace std;
int main(){
    int n; 
    cin>>n;
    int sum=0;
    int i=1;
    while(i<=n){
        sum=sum+1;
        i=i+1;
    }
    cout<<sum<<endl;
    return 0;

}