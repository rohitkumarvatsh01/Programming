#include<iostream>
using namespace std;

int main(){
    
    
    int num1;
    cout<<"Enter the value of num 1 :- "<<endl;
    cin>>num1;
    
    int num2;
    cout<<"Enter the value of num 2 :- "<<endl;
    cin>>num2;

    int sum = num1 + num2;

    cout<<"Sum of the number:- "<<sum<<endl;

    return 0;


}