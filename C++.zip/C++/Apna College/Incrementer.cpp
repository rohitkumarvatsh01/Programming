#include<iostream>
using namespace std;
int main(){
    int n;
    for(int i=5; i>=51; i+5){
        cout<< i <<endl;
    }
    return 0;
}