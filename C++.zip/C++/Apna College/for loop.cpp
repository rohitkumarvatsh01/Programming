#include<iostream>
using namespace std;

int main(){
    int n;
    cout<<"Enter the Value:- ";
    cin>>n;

    for(int i=0; i<=n; i++){
        cout<<"Priya Kumari "<<endl;
    }
    return 0;

}