#include<iostream>
using namespace std;

int main()
{
    int a=3;
    cout<<a<<endl;
    if(true){
        cout<<a<<endl;
    }

    return 0;
}