#include<iostream>
using namespace std;

int main()
{
    int b=2;
    int b=3;
    int b=4;
    cout<<b;
    return 0;

    //error dega kyu ki hm ek variable use krerge ek block me
    
}