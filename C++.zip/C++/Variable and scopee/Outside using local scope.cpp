#include<iostream>
using namespace std;

int main()
{
    int i=8;
    if(1){
        int b=1;
        if(i){
            int b=2;
            if(1){
                int b=3;
                cout<<b;
            }
        }
    }
    
    return 0;
}