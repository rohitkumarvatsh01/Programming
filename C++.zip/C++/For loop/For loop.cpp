#include<iostream>
using namespace std;
int main()
{
    for(int i=0; i<5; i++){
        cout<<"Hi"<<endl;
        cout<<"Hey"<<endl;
        continue;

        cout<<"Nhi print hoga kyu ki break ki wajah se"<<endl;
    }
    return 0;
}