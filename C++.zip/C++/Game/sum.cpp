#include<iostream>
using namespace std;
int main(){
    int a;
    int b;
    cout<<"Enter the value of a:- "<<endl;
    cin>>a;
    cout<<"Enter the value of b:- "<<endl;
    cin>>b;

    int sum=a+b;

    cout<<"The value of a+b is:- "<<sum<<endl;
    return 0;
}